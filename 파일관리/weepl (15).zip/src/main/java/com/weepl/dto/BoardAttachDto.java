package com.weepl.dto;

import org.modelmapper.ModelMapper;

import com.weepl.entity.BoardAttach;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BoardAttachDto {
	
	private Long cd;
	
	private String attachName;
	
	private String oriAttachName;
	
	private String attachUrl;
	
	private String board_div;
	
	private static ModelMapper modelMapper = new ModelMapper();
	
	public static BoardAttachDto of(BoardAttach boardAttach) {
		return modelMapper.map(boardAttach, BoardAttachDto.class);
	}
}
