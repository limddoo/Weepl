package com.weepl.constant;

public enum DeleteStatus {
	Alived, Deleted
}
