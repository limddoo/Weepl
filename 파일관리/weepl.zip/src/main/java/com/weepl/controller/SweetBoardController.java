package com.weepl.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.weepl.service.SweetBoardService;

import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
@RequestMapping(value="/sweetboard")
public class SweetBoardController {
	
	private final SweetBoardService sweetBoardService;
	
	@GetMapping(value="/sweetlist")
	public String SweetBoardList(Model model) {
		return "sweetboard/sweetBoard";	
	}
	
	@GetMapping(value="/sweetdtl")
	public String SweetBoardDetail(Model model) {
		return "sweetboard/sweetDetail";
	}
	
	@PostMapping(value="/addsweet")
	public String addSweetBoard(Model model) {
//		SweetBoardDto sweetBoardDto = new SweetBoardDto();
		
		return "sweetboard/sweetForm";
	}
		
}
