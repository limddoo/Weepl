package com.weepl.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.weepl.entity.SweetBoard;

public interface SweetBoardRepository extends JpaRepository<SweetBoard, Long> {
	
}
