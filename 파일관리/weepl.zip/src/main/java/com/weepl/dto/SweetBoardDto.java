package com.weepl.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SweetBoardDto {
	
	public String title;
	
	public String content;
	
	public String board_div;
	
	public long like_cnt;
	
	public String del_yn;
	
	public SweetBoardDto() {
		super();
	}
	
	public SweetBoardDto(String title, String content, String board_div, long like_cnt, String del_yn) {
		super();
		this.title = title;
		this.content = content;
		this.board_div = board_div;
		this.like_cnt = like_cnt;
		this.del_yn = del_yn;
	}
	
}
