package com.weepl.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.weepl.repository.SweetBoardRepository;

import lombok.RequiredArgsConstructor;

@Service
@Transactional
@RequiredArgsConstructor
public class SweetBoardService {
		private final SweetBoardRepository sweetBoardRepository;
	
}
