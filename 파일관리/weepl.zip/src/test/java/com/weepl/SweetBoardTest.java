package com.weepl;

import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;

import com.weepl.constant.DeleteStatus;
import com.weepl.entity.SweetBoard;
import com.weepl.repository.SweetBoardRepository;

@SpringBootTest
@TestPropertySource(locations="classpath:application-test.properties")
public class SweetBoardTest {
	
	@Autowired
	SweetBoardRepository sweetBoardRepository;
	
	@Test
	public void SweetBoardTest() {
		SweetBoard sweetBoard = new SweetBoard();
		sweetBoard.setTitle("새 게시글 제목");
		sweetBoard.setContent("첫번째 새 게시글 내용입니다.");
		sweetBoard.setBoard_div("학교 업무");
		sweetBoard.setLike_cnt(10);
		sweetBoard.setRegTime(LocalDateTime.now());
		sweetBoard.setUpdateTime(LocalDateTime.now());
		sweetBoard.setDel_yn(DeleteStatus.Deleted);
		SweetBoard savedSweetBoard = sweetBoardRepository.save(sweetBoard);
		
		
		SweetBoard sweetBoard1 = new SweetBoard();
		sweetBoard1.setTitle("새 게시글 제목");
		sweetBoard1.setContent("두번째 게시글 내용입니다.");
		sweetBoard1.setBoard_div("상담 전문성 공유");
		sweetBoard1.setLike_cnt(10);
		sweetBoard1.setRegTime(LocalDateTime.now());
		sweetBoard1.setUpdateTime(LocalDateTime.now());
		sweetBoard1.setDel_yn(DeleteStatus.Alived);
		SweetBoard savedSweetBoard1 = sweetBoardRepository.save(sweetBoard1);
	}
}
