package com.weepl.constant;

public enum ReserveStatus {
	WAITING, APPLIED, REFUSED, CANCLED
}
