//package com.weepl.repository;
//
//import java.util.List;
//
//import org.springframework.stereotype.Repository;
//
//import com.weepl.entity.Mhinfo;
//
//@Repository
//public interface MhinfoCateRepository {
//
//	List<Mhinfo> findbyCd(Long cd);
//}
