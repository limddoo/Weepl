package com.weepl.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import org.modelmapper.ModelMapper;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@NoArgsConstructor
@ToString
@EqualsAndHashCode(callSuper = true)
@Table(name = "SWEETCOMM")
public class SweetComment extends BaseEntity {
	
	@Id
	@Column(name="comm_cd")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long cd;	// 댓글 고유번호
	
	@Lob
	@Column(name="comm_content", nullable = false)
	private String comment;
	
	// 댓글 삭제 여부
	@Column(nullable = false)
	private String del_yn;
	
	// 댓글 작성자
	private String createdBy;
	
	// 회원정보
	@ManyToOne
	@JoinColumn(name="mem_cd")
	private Member member;
	
	// 원본 댓글 고유번호
	@ManyToOne(fetch= FetchType.LAZY)
	@JoinColumn(name= "ori_comm_cd")
	private SweetComment oriCd;
	
	// 하위 댓글
	@OneToMany(mappedBy= "oriCd")
	private List<SweetComment> comments = new ArrayList<>();
	
	// 게시글
	@ManyToOne
	@JoinColumn(name="sweet_board_cd")
	@OnDelete(action = OnDeleteAction.CASCADE)
	private SweetBoard sweetBoard;
	
	public void updateComment(String comment) {
		this.comment = comment;
	}
	
	public void updateDelYn(String del_yn) {
		this.del_yn = del_yn;
	}

	private static ModelMapper modelMapper = new ModelMapper();
	
	public SweetComment createSweetComment() {
		return modelMapper.map(this, SweetComment.class);		// dto를 entity로
	}
}
