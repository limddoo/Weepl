package com.weepl.constant;

public enum Role {
	ADMIN, CLIENT, COUNSELOR
}
