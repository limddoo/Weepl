package com.weepl.dto;

import lombok.Data;

@Data
public class UntactConsSchDto {
	private String schDates;
}
