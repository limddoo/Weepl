package com.weepl.constant;

public enum MhinfoCate {
	SCHOOL, MIND, RELATIONSHIP
}
