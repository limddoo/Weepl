package com.weepl.dto;

import org.modelmapper.ModelMapper;

import com.weepl.entity.BoardImg;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class BoardImgDto {
	
	// 고유번호
	private Long cd;
	
	// 이미지명
	private String imgName;
	
	// 원본 이미지명
	private String oriImgName;
	
	// 조회 경로
	private String imgUrl;
	
	// 대표 이미지 여부
	private String repImgYn;
	
	// 게시판 구분
	private String boardDiv;
	
	private static ModelMapper modelMapper = new ModelMapper();
	
	public static BoardImgDto of(BoardImg boardImg) {	// entity를 dto로
		return modelMapper.map(boardImg, BoardImgDto.class);
	}
}