package com.weepl.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name="BOARDIMG")
@Getter
@Setter
public class BoardImg extends BaseEntity {

	@Id
	@Column(name="board_img_cd")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long cd;
	
	// 이미지 파일명
	private String imgName;
	
	// 원본 이미지 파일명
	private String oriImgName;
	
	// 이미지 조회 경로
	private String imgUrl;
	
	// 대표 이미지 여부
	private String repImgYn;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "sweet_board_cd")
	@OnDelete(action= OnDeleteAction.CASCADE)
	private SweetBoard sweetBoard;
	
	public void updateBoardImg(String oriImgName, String imgName, String imgUrl) {
		this.oriImgName = oriImgName;
		this.imgName = imgName;
		this.imgUrl = imgUrl;
	}
}
