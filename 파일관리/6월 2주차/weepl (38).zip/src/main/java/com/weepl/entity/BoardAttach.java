package com.weepl.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name="BOARDATTACH")
@Getter
@Setter
public class BoardAttach extends BaseEntity {

	// 첨부파일 고유번호
	@Id
	@Column(name="attach_cd")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long cd;
	
	// 첨부파일명
	@Column(name="attach_name")
	private String attachName;
	
	// 원본 첨부파일명
	@Column(name="ori_attach_name")
	private String oriAttachName;
	
	// 첨부파일 조회경로
	@Column(name="attach_url")
	private String attachUrl;

	// 게시판 구분
	private String board_div;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="sweet_board_cd")
	@OnDelete(action=OnDeleteAction.CASCADE)
	private SweetBoard sweetBoard;
	
	// 첨부파일 수정
	public void updateBoardAttach(String oriAttachName, String attachName, String attachUrl) {
		this.oriAttachName = oriAttachName;
		this.attachName = attachName;
		this.attachUrl = attachUrl;	
	}
	public void setSweetBoard(SweetBoard sweetBoard) {
		this.sweetBoard = sweetBoard;
	}
	
}
