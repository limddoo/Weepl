package com.weepl.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.weepl.entity.BoardImg;

public interface BoardImgRepository extends JpaRepository<BoardImg, Long>{
	
	List<BoardImg> findBySweetBoardCdOrderByCdAsc(Long cd);
}
