package com.weepl;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.TestPropertySource;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.weepl.dto.SweetBoardDto;
import com.weepl.entity.SweetBoard;
import com.weepl.repository.SweetBoardRepository;
import com.weepl.service.SweetBoardService;

@SpringBootTest
@Transactional
@TestPropertySource(locations = "classpath:application-test.properties")
public class SweetBoardServiceTest {

	@Autowired
	SweetBoardService sweetBoardService;

	@Autowired
	SweetBoardRepository sweetBoardRepository;

	List<MultipartFile> createMultipartFiles() throws Exception {
		List<MultipartFile> multipartFileList = new ArrayList<>();
		for (int i = 0; i < 5; i++) {
			String path = "D:/wee/boardImg";
			String imageName = "image" + i + ".jpg";
			MockMultipartFile multipartFile = new MockMultipartFile(path, imageName, "image/jpg",
					new byte[] { 1, 2, 3, 4 });
			multipartFileList.add(multipartFile);
		}
		return multipartFileList;
	}

	@Test
	@DisplayName("글 저장 테스트")
	@WithMockUser(username = "counselor", roles = "COUNSELOR")
	void saveSweetBoard() throws Exception {
		SweetBoardDto sweetBoardDto = new SweetBoardDto();
		sweetBoardDto.setBoard_div("학교업무 공유게시판");
		sweetBoardDto.setTitle("테스트 작성하는 글");
		sweetBoardDto.setContent("테스트 내용을 입력하세요.");
		sweetBoardDto.setLike_cnt(0);
		sweetBoardDto.setDel_yn("N");

		List<MultipartFile> multipartFileList = createMultipartFiles();
		List<MultipartFile> multipartAttachList = createMultipartFiles();
		Long sweetBoardCd = sweetBoardService.saveSweetBoard(sweetBoardDto, multipartFileList, multipartAttachList);

		SweetBoard sweetBoard = sweetBoardRepository.findByCd(sweetBoardCd);

		assertEquals(sweetBoardDto.getTitle(), sweetBoard.getTitle());
		assertEquals(sweetBoardDto.getContent(), sweetBoard.getContent());
		assertEquals(sweetBoardDto.getBoard_div(), sweetBoard.getBoard_div());
		assertEquals(sweetBoardDto.getLike_cnt(), sweetBoard.getLike_cnt());
		assertEquals(sweetBoardDto.getDel_yn(), sweetBoard.getDel_yn());
	}
}
