package com.weepl.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.weepl.dto.SweetBoardDto;
import com.weepl.service.SweetBoardService;

import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
@RequestMapping(value="/sweetboard")
public class SweetBoardController {
	
	private final SweetBoardService sweetBoardService;
	
	@GetMapping(value="/list")
	public String SweetBoardList(Model model) {
		List<SweetBoardDto> sweetBoardList = new ArrayList<>();
		
		for(int i=1;i<=10;i++){
			SweetBoardDto sweetBoardDto = new SweetBoardDto();
			sweetBoardDto.setTitle("i 번째 게시글");
			sweetBoardDto.setContent("게시글 내용");
			sweetBoardDto.setBoard_div("학교 업무 공유 게시판");
			sweetBoardList.add(sweetBoardDto);
		}
		
		model.addAttribute("sweetBoardList",sweetBoardList);
		return "sweetboard/sweetBoard";
	}
	
	@GetMapping(value="/dtl")
	public String SweetBoardDetail(Model model) {
		model.addAttribute("SweetBoardDto", new SweetBoardDto());
		return "sweetboard/sweetDetail";
	}
	
	@GetMapping(value="/add")
	public String addSweetBoard(Model model) {
		model.addAttribute("SweetBoardDto", new SweetBoardDto());
		return "sweetboard/sweetForm";
	}
	
	@PostMapping(value="/counselor/board/add")
	public String addSweetBoard(@Valid SweetBoardDto sweetBoardDto, BindingResult bindingResult, Model model) {
		if (bindingResult.hasErrors()) {
			return "sweetboard/sweetForm";
		}
		
		return "redirect:/"; // project2_slide_56
	}
	
	@GetMapping(value="/clone")
	public String cloneTest(Model model) {
		model.addAttribute("SweetBoardDto", new SweetBoardDto());
		return "sweetboard/sweetMain";
	}
		
}
