package com.weepl.dto;

public class SweetBoardImgDto {

}
