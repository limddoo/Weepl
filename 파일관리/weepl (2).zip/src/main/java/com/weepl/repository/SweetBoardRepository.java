package com.weepl.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.weepl.entity.SweetBoard;

public interface SweetBoardRepository extends JpaRepository<SweetBoard, Long> {

	List<SweetBoard> findByTitle(String title);
}