package com.weepl.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UntactConsDto {
	private Long memCd;
	private String memName;
	private String reserveDate;
	private String reserveTime;
}
