package com.weepl.constant;

public enum RestrictStatus {
	RESTRICTED,	UNRESTRICTED
}
