package com.weepl.service;

import javax.persistence.EntityNotFoundException;

import org.apache.groovy.parser.antlr4.util.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.weepl.entity.BoardImg;
import com.weepl.repository.BoardImgRepository;

import lombok.RequiredArgsConstructor;

@Service
@Transactional
@RequiredArgsConstructor
public class BoardImgService {
	
	@Value("${boardImgLocation}") // application.properties에 등록한 itemImgLocation값을 itemImgLocation에 저장
	private String boardImgLocation;
	
	private final BoardImgRepository boardImgRepository;
	
	private final FileService fileService;
	
	// 이미지 저장
	public void saveBoardImg(BoardImg boardImg, MultipartFile boardImgFile) throws Exception {
		String oriImgName = boardImgFile.getOriginalFilename();
		String imgName = "";
		String imgUrl = "";
		
		// 파일 업로드
		if(!StringUtils.isEmpty(oriImgName)) {
			// 이미지를 등록 시 경로, 파일명, 파일 바이트 수를 파라미터로 하는 uploadFile 메서드 호출
			imgName = fileService.uploadFile(boardImgLocation, oriImgName, boardImgFile.getBytes());
			imgUrl = "/wee/boardImg" + imgName;
		}
		
		// 이미지 정보 저장
		boardImg.updateBoardImg(oriImgName, imgName, imgUrl); // 원래 파일명, 로컬 파일명, 경로
		boardImgRepository.save(boardImg);	// 이미지 정보 저장
	}
	
	public void updateBoardImg(Long boardImgCd, MultipartFile boardImgFile) throws Exception {
		if(!boardImgFile.isEmpty()) {
			BoardImg savedBoardImg = boardImgRepository.findById(boardImgCd)
					.orElseThrow(EntityNotFoundException::new);
			
			// 기존 이미지 파일 삭제
			if(!StringUtils.isEmpty(savedBoardImg.getImgName())) {
				fileService.deleteFile(boardImgLocation+"/"+savedBoardImg.getImgName());
			}
			String oriImgName = boardImgFile.getOriginalFilename();
			String imgName = fileService.uploadFile(boardImgLocation, oriImgName, boardImgFile.getBytes());
			String imgUrl = "/wee/boardImg" + imgName;
			savedBoardImg.updateBoardImg(oriImgName, imgName, imgUrl);
		}
	}
}
