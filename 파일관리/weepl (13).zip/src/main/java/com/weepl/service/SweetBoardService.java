package com.weepl.service;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityNotFoundException;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.weepl.dto.BoardImgDto;
import com.weepl.dto.SweetBoardDto;
import com.weepl.dto.SweetSearchDto;
import com.weepl.entity.BoardImg;
import com.weepl.entity.SweetBoard;
import com.weepl.repository.BoardImgRepository;
import com.weepl.repository.SweetBoardRepository;

import lombok.RequiredArgsConstructor;

@Service
@Transactional
@RequiredArgsConstructor
public class SweetBoardService {
	
	private final SweetBoardRepository sweetBoardRepository;
	private final BoardImgService boardImgService;
	private final BoardImgRepository boardImgRepository;
	
	public Long saveSweetBoard(SweetBoardDto sweetBoardDto, List<MultipartFile> boardImgFileList) throws Exception {
		SweetBoard sweetBoard = sweetBoardDto.createSweetBoard();
		sweetBoardRepository.save(sweetBoard);
		
		for (int i = 0; i < boardImgFileList.size(); i++) {
			BoardImg boardImg = new BoardImg();
			boardImg.setSweetBoard(sweetBoard);
			
			if (i==0)
				boardImg.setRepImgYn("Y");
			else
				boardImg.setRepImgYn("N");
			
			boardImgService.saveBoardImg(boardImg, boardImgFileList.get(i));
		}
		return sweetBoard.getCd();
	}
	
	@Transactional(readOnly = true)
	public Page<SweetBoard> getSweetBoardPage(SweetSearchDto sweetSearchDto, Pageable pageable) {
		return sweetBoardRepository.getSweetBoardPage(sweetSearchDto, pageable);
	}
	
	@Transactional(readOnly = true)
	public SweetBoardDto getSweetBoardDtl(Long cd) {
		List<BoardImg> boardImgList = boardImgRepository.findBySweetBoardCdOrderByCdAsc(cd);
		List<BoardImgDto> boardImgDtoList = new ArrayList<>();
		
		for (BoardImg boardImg : boardImgList) {
			BoardImgDto boardImgDto = BoardImgDto.of(boardImg);
			boardImgDtoList.add(boardImgDto);
		}
		
		SweetBoard sweetBoard = sweetBoardRepository.findById(cd)
				.orElseThrow(EntityNotFoundException::new);
		SweetBoardDto sweetBoardDto = SweetBoardDto.of(sweetBoard);
		sweetBoardDto.setBoardImgDtoList(boardImgDtoList);
		return sweetBoardDto;
	}
	
	public Long updateSweetBoard(SweetBoardDto sweetBoardDto, List<MultipartFile> boardImgFileList) throws Exception {
		// 상품 수정
		SweetBoard sweetBoard = sweetBoardRepository.findById(sweetBoardDto.getCd())
				.orElseThrow(EntityNotFoundException::new);
		sweetBoard.updateSweetBoard(sweetBoardDto);
		
		// 이미지 수정
		List<Long> boardImgCds = sweetBoardDto.getBoardImgCds();
		for (int i = 0; i < boardImgFileList.size(); i++) {
			boardImgService.updateBoardImg(boardImgCds.get(i), boardImgFileList.get(i));
		}
		return sweetBoard.getCd();
	}
	
	public void deleteSweetBoard(Long cd) {
		sweetBoardRepository.deleteById(cd);
	}
	
}
