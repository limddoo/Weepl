package com.weepl;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.TestPropertySource;
import org.springframework.transaction.annotation.Transactional;

import com.weepl.dto.SweetBoardDto;
import com.weepl.entity.SweetBoard;
import com.weepl.repository.SweetBoardRepository;
import com.weepl.service.SweetBoardService;

@SpringBootTest
@Transactional
@TestPropertySource(locations="classpath:application-test.properties")
public class SweetBoardServiceTest {
	
	@Autowired
	SweetBoardService sweetBoardService;
	
	@Autowired
	SweetBoardRepository sweetBoardRepository;
	
	@Test
	@DisplayName("글 저장 테스트")
	@WithMockUser(username="counselor", roles="COUNSELOR")
	void saveSweetBoard() throws Exception {
		SweetBoardDto sweetBoardDto = new SweetBoardDto();
		sweetBoardDto.setBoard_div("학교업무 공유게시판");
		sweetBoardDto.setTitle("테스트 작성하는 글");
		sweetBoardDto.setContent("테스트 내용을 입력하세요.");
		sweetBoardDto.setLike_cnt(0);
		sweetBoardDto.setDel_yn("N");
		
		Long sweetBoardCd = sweetBoardService.saveSweetBoard(sweetBoardDto);
		
		SweetBoard sweetBoard = sweetBoardRepository.findByCd(sweetBoardCd);
		
		assertEquals(sweetBoardDto.getTitle(), sweetBoard.getTitle());
		assertEquals(sweetBoardDto.getContent(),sweetBoard.getContent());
		assertEquals(sweetBoardDto.getBoard_div(), sweetBoard.getBoard_div());
		assertEquals(sweetBoardDto.getLike_cnt(), sweetBoard.getLike_cnt());
		assertEquals(sweetBoardDto.getDel_yn(), sweetBoard.getDel_yn());
	}
}
