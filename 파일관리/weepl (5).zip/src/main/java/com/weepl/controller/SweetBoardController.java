package com.weepl.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.weepl.dto.SweetBoardDto;
import com.weepl.dto.SweetSearchDto;
import com.weepl.entity.SweetBoard;
import com.weepl.service.SweetBoardService;

import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
@RequestMapping(value="/sweetboard")
public class SweetBoardController {
	
	private final SweetBoardService sweetBoardService;
	
	@GetMapping(value= {"/list", "/list/{page}"})
	public String SweetBoardManage(SweetSearchDto sweetSearchDto,
				@PathVariable("page") Optional<Integer>page, Model model) {
		Pageable pageable = PageRequest.of(page.isPresent() ? page.get() : 0,3);
		
		Page<SweetBoard> sweetBoards = sweetBoardService.getSweetBoardPage(sweetSearchDto, pageable);
		
		model.addAttribute("sweetBoards", sweetBoards);
		model.addAttribute("sweetSearchDto", sweetSearchDto);
		model.addAttribute("maxPage", 5);
	
		return "sweetboard/sweetList";
	}
	
//	@GetMapping(value="/list")
//	public String SweetBoardList(Model model) {
//		List<SweetBoardDto> sweetBoardDto = new ArrayList<>();
//		
//		model.addAttribute("sweetBoardDto", sweetBoardDto);
//		// 추가 요망
//		return "sweetboard/sweetBoard";
//	}
	
	@PostMapping(value="/list")
	public String SweetBoard(Model model) {
		return "redirect:/sweetboard/list";
	}
	
	@GetMapping(value="/dtl")
	public String SweetBoardDetail(Model model) {
		model.addAttribute("SweetBoardDto", new SweetBoardDto());
		return "sweetboard/sweetDetail";
	}
	
	@GetMapping(value="/add")
	public String cloneTest(Model model) {
		model.addAttribute("sweetBoardDto", new SweetBoardDto());
		return "sweetboard/sweetForm";
	}
	
	@PostMapping(value="/add")
	public String addSweetBoard(@Valid SweetBoardDto sweetBoardDto, BindingResult bindingResult, Model model) {
		if(bindingResult.hasErrors()) {
			return "sweetboard/sweetForm";
		}
		try {
			sweetBoardService.saveSweetBoard(sweetBoardDto);
		} catch (Exception e) {
			model.addAttribute("errorMessage", "글을 저장하는 중 에러가 발생하였습니다.");
			return "sweetBoard/sweetForm";
		}
		return "redirect:/sweetboard/list";
	}
	
	
	
}
