package com.weepl.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.weepl.dto.SweetBoardDto;
import com.weepl.dto.SweetSearchDto;
import com.weepl.entity.SweetBoard;
import com.weepl.repository.SweetBoardRepository;

import lombok.RequiredArgsConstructor;

@Service
@Transactional
@RequiredArgsConstructor
public class SweetBoardService {
	
	private final SweetBoardRepository sweetBoardRepository;
	
//	public SweetBoard saveSweet(SweetBoard sweetBoard) {
//		return sweetBoardRepository.save(sweetBoard);
//	}
//	
//	@Transactional(readOnly=true)
//	public List<SweetBoard> getSweetList(SweetBoardDto sweetBoardDto, String title) {
//		List<SweetBoard> sweetBoardList = new ArrayList<>();
//		sweetBoardList = sweetBoardRepository.findByTitle(title);
//		return sweetBoardList;
//	}
	
	public Long saveSweetBoard(SweetBoardDto sweetBoardDto) throws Exception {
		SweetBoard sweetBoard = sweetBoardDto.createSweet();
		sweetBoardRepository.save(sweetBoard);
		return sweetBoard.getCd();
	}
	
	@Transactional(readOnly = true)
	public Page<SweetBoard> getSweetBoardPage(SweetSearchDto sweetSearchDto, Pageable pageable) {
		return sweetBoardRepository.getSweetBoardPage(sweetSearchDto, pageable);
	}
}
