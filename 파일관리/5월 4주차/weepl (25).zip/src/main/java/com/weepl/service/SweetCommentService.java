package com.weepl.service;

import javax.persistence.EntityNotFoundException;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.weepl.entity.SweetBoard;
import com.weepl.entity.SweetComment;
import com.weepl.repository.SweetBoardRepository;
import com.weepl.repository.SweetCommentRepository;

import lombok.RequiredArgsConstructor;

@Service
@Transactional
@RequiredArgsConstructor
public class SweetCommentService {
	
	private final SweetCommentRepository sweetCommentRepository;
	private final SweetBoardRepository sweetBoardRepository;
	
	// 댓글 등록
	@Transactional
	public void addComment(Long id, SweetComment sweetComment) {
		SweetBoard sweetBoard = sweetBoardRepository.findById(id)
				.orElseThrow(EntityNotFoundException::new);
		sweetComment.setSweetBoard(sweetBoard);
		sweetCommentRepository.save(sweetComment);
	}
	
	// 댓글 삭제
	@Transactional
	public void deleteComment(Long cd) {
		SweetComment sweetComment = sweetCommentRepository.findById(cd)
				.orElseThrow(EntityNotFoundException::new);
		sweetCommentRepository.delete(sweetComment);
	}
	
	// 좋아요 수 업데이트
	public void updateLikeCnt(Long cd, int like_cnt) {
		SweetBoard sweetBoard = sweetBoardRepository.findById(cd)
				.orElseThrow(EntityNotFoundException::new);
		sweetBoard.updateLikeCnt(like_cnt);
	}
}