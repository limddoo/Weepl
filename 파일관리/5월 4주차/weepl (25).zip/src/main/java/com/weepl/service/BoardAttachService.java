package com.weepl.service;

import javax.persistence.EntityNotFoundException;

import org.apache.groovy.parser.antlr4.util.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.weepl.entity.BoardAttach;
import com.weepl.repository.BoardAttachRepository;

import lombok.RequiredArgsConstructor;

@Service
@Transactional
@RequiredArgsConstructor
public class BoardAttachService {
	
	@Value("${boardImgLocation}")
	private String boardAttachLocation;
	
	private final BoardAttachRepository boardAttachRepository;
	private final FileService fileService;
	
	public void saveBoardAttach(BoardAttach boardAttach, MultipartFile boardAttachFile) throws Exception {
		String oriAttachName = boardAttachFile.getOriginalFilename();
		String attachName = "";
		String attachUrl = "";
		
		// 첨부파일 다중 업로드
		if (!StringUtils.isEmpty(oriAttachName)) {
			attachName = fileService.uploadFile(boardAttachLocation, oriAttachName, boardAttachFile.getBytes());
			attachUrl = "/wee/boardImg/" + attachName;
			System.out.println(attachName);
			System.out.println(attachUrl);
		}
		// 첨부파일 정보 저장
		boardAttach.updateBoardAttach(oriAttachName, attachName, attachUrl);
		boardAttachRepository.save(boardAttach);
	}
	
	public void updateBoardAttach(Long boardAttachCd, MultipartFile boardAttachFile) throws Exception {
		if(!boardAttachFile.isEmpty()) {
			BoardAttach savedBoardAttach = boardAttachRepository.findById(boardAttachCd)
					.orElseThrow(EntityNotFoundException::new);
			// 기존 첨부파일 삭제
			if(!StringUtils.isEmpty(savedBoardAttach.getAttachName())) {
				fileService.deleteFile(boardAttachLocation+"/"+savedBoardAttach.getAttachName());
			}
			String oriAttachName = boardAttachFile.getOriginalFilename();
			String attachName = fileService.uploadFile(boardAttachLocation, oriAttachName, boardAttachFile.getBytes());
			String attachUrl =  "/wee/boardImg/" + attachName;
			savedBoardAttach.updateBoardAttach(oriAttachName, attachName, attachUrl);
		}
	}
}
