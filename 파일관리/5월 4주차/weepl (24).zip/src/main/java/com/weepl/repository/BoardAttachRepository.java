package com.weepl.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.weepl.entity.BoardAttach;

public interface BoardAttachRepository extends JpaRepository<BoardAttach, Long>{
	
}
