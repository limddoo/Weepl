package com.weepl.constant;

public enum OrderStatus {
	ORDER, CANCEL
}
