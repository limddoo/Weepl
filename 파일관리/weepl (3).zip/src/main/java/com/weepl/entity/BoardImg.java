package com.weepl.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name="BOARDIMG")
@Getter
@Setter
public class BoardImg extends BaseEntity {

	@Id
	@Column(name="board_img_cd")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long cd;
	
	// 이미지 파일명
	private String img_name;
	
	// 원본 이미지 파일명
	private String ori_img_name;
	
	// 이미지 조회 경로
	private String img_url;
	
	// 대표 이미지 여부
	private String rep_img_yn;
	
	// 게시판 구분
	private String board_div;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="sweet_board_cd")
	private SweetBoard sweetBoard;
	
	public void updateBoardImg(String ori_img_name, String img_name, String img_url) {
		this.ori_img_name = ori_img_name;
		this.img_name = img_name;
		this.img_url = img_url;
	}
}
