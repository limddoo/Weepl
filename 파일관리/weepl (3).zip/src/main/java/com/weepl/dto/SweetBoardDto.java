package com.weepl.dto;

import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.NotBlank;

import org.modelmapper.ModelMapper;

import com.weepl.entity.SweetBoard;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SweetBoardDto {
	
	// 게시글 순번
	private Long cd;
	
	// 게시글 제목
	@NotBlank(message="제목을 2자 이상 입력해주세요.")
	private String title;
	
	// 게시글 내용
	@NotBlank(message="내용을 2자 이상 입력해주세요.")
	private String content;
	
	// 게시판 구분
	private String board_div;
	
	// 좋아요 개수 카운트
	private int like_cnt;
	
	// 삭제 여부
	private String del_yn;
	
	private List<BoardImgDto> boardImgDtoList = new ArrayList<>();
	
	private List<Long> BoardImgCds = new ArrayList<>();
	
	public SweetBoardDto() {
		super();
	}
	
	public SweetBoardDto(String title, String content, String board_div, int like_cnt, String del_yn) {
		super();
		this.title = title;
		this.content = content;
		this.board_div = board_div;
		this.del_yn = del_yn;
	}
	
	private static ModelMapper modelMapper = new ModelMapper();
	
	public SweetBoard createSweet() {
		return modelMapper.map(this, SweetBoard.class);
	}
	
	public static SweetBoardDto of(SweetBoard sweetBoard) {
		return modelMapper.map(sweetBoard, SweetBoardDto.class);
	}
	
}
