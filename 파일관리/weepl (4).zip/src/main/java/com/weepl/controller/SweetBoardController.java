package com.weepl.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.weepl.dto.SweetBoardDto;
import com.weepl.entity.SweetBoard;
import com.weepl.service.SweetBoardService;

import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
@RequestMapping(value="/sweetboard")
public class SweetBoardController {
	
	private final SweetBoardService sweetBoardService;
	
	@GetMapping(value="/list")
	public String SweetBoardList(Model model) {
		SweetBoardDto sweetBoardDto = new SweetBoardDto();
		sweetBoardDto.setTitle("첫번째 게시글");
		sweetBoardDto.setContent("게시글 내용 예시");
		sweetBoardDto.setBoard_div("학교 업무 공유 게시판");
		model.addAttribute("sweetBoardDto", sweetBoardDto);
		return "sweetboard/sweetBoard";
	}
	
	@GetMapping(value="/dtl")
	public String SweetBoardDetail(Model model) {
		model.addAttribute("SweetBoardDto", new SweetBoardDto());
		return "sweetboard/sweetDetail";
	}
	
	@GetMapping(value="/add")
	public String cloneTest(Model model) {
		model.addAttribute("sweetBoardDto", new SweetBoardDto());
		return "sweetboard/sweetForm";
	}
	
	@PostMapping(value="/add")
	public String addSweetBoard(@Valid SweetBoardDto sweetBoardDto, BindingResult bindingResult, Model model) {
		SweetBoard sweetBoard = SweetBoard.createSweetBoard(sweetBoardDto);
		sweetBoardService.saveSweet(sweetBoard);
		return "redirect:/"; // project2_slide_56
	}
	
}
