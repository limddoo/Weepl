package com.weepl.dto;

import org.modelmapper.ModelMapper;

import com.weepl.entity.BoardImg;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BoardImgDto {
	
	// 고유번호
	private Long cd;
	
	// 이미지명
	private String img_name;
	
	// 원본 이미지명
	private String ori_img_name;
	
	// 조회 경로
	private String img_url;
	
	// 대표 이미지 여부
	private String rep_img_yn;
	
	// 게시판 구분
	private String board_div;
	
	private static ModelMapper modelMapper = new ModelMapper();
	
	public static BoardImgDto of(BoardImg boardImg) {
		return modelMapper.map(boardImg, BoardImgDto.class);
	}
}
