package com.weepl.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.weepl.dto.SweetBoardDto;
import com.weepl.entity.SweetBoard;
import com.weepl.repository.SweetBoardRepository;

import lombok.RequiredArgsConstructor;

@Service
@Transactional
@RequiredArgsConstructor
public class SweetBoardService {
	
	private final SweetBoardRepository sweetBoardRepository;
	
	public SweetBoard saveSweet(SweetBoard sweetBoard) {
//		validateDuplicateSweetBoard(sweetBoard);
		return sweetBoardRepository.save(sweetBoard);
	}
	
//	public void validateDuplicateSweetBoard(SweetBoard sweetBoard) {
//		
//		SweetBoard findSweet = sweetBoardRepository.findByTitle(sweetBoard.getTitle());
//	}
	
	@Transactional(readOnly=true)
	public List<SweetBoard> getSweetList(SweetBoardDto sweetBoardDto, String title) {
		List<SweetBoard> sweetBoardList = new ArrayList<>();
		sweetBoardList = sweetBoardRepository.findByTitle(title);
		return sweetBoardList;
	}
}
