package com.weepl.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SweetSearchDto {

	private String searchDateType;
	
	private String searchBoardDiv;
	
	private String searchBy;
	
	private String searchQuery = "";
}
