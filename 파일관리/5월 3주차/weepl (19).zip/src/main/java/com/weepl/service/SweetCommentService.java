package com.weepl.service;

import javax.persistence.EntityNotFoundException;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.weepl.dto.SweetCommentDto;
import com.weepl.entity.Member;
import com.weepl.entity.SweetBoard;
import com.weepl.repository.MemberRepository;
import com.weepl.repository.SweetBoardRepository;

import lombok.RequiredArgsConstructor;

@Service
@Transactional
@RequiredArgsConstructor
public class SweetCommentService {
	
//	private final SweetCommentRepository sweetCommentRepository;
	private final MemberRepository memberRepository;
	private final SweetBoardRepository sweetBoardRepository;
	
	@Transactional
	public Long commentSave(String id, Long cd, SweetCommentDto sweetCommentDto) {
		Member member = memberRepository.findById(id);
		SweetBoard sweetBoard = sweetBoardRepository.findById(cd)
				.orElseThrow(EntityNotFoundException::new);
		sweetCommentDto.setMember(member);
		sweetCommentDto.setSweetBoard(sweetBoard);
	
		return sweetCommentDto.getId();
	}
}
