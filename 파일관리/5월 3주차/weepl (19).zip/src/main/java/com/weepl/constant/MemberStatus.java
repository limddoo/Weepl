package com.weepl.constant;

public enum MemberStatus {
	GENERAL, RESTRICT, QUIT
}
