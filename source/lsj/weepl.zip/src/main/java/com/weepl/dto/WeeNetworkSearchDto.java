package com.weepl.dto;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class WeeNetworkSearchDto {

	private String agencyName;
    private String locName;

}
