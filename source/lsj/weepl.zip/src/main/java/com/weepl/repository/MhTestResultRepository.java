package com.weepl.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.weepl.entity.MhTestResult;

public interface MhTestResultRepository extends JpaRepository<MhTestResult, Long>{

}
