package com.weepl;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WeeplApplicationTests {

	@Test
	void contextLoads() {
	}

}
