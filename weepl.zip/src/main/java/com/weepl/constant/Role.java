package com.weepl.constant;

public enum Role {
	USER, ADMIN
}
