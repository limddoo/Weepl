package com.weepl.constant;

public enum ItemSellStatus {
	SELL, SOLD_OUT
}
